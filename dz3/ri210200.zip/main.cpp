#include "helpers.h"

int main() {
	helpers::mainLoop();
}